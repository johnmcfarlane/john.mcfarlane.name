/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   main.cpp - main function of the program
******************************************/

#include "CA.h"

#include <iostream>


int main (int argc , char * argv []) 
{
	std::cout << "Lottery Number Generator\n";
	std::cout << "(c)2007 John McFarlane\n";
	std::cout << "http://john.mcfarlane.name/projects/lottery\n";
	
	unsigned int seed1 = (argc >= 2) ? atoi(argv[1]) : time(0);
	srand(seed1);
	std::cout << "\ninitial random seed = " << seed1 << std::endl;

	CA number_generator;

	number_generator.run();

	unsigned int seed2 = (argc >= 3) ? atoi(argv[2]) : time(0);
	srand(seed2);
	std::cout << "\nfinal result random seed = " << seed2 << std::endl;

	std::cout << '\t';
	number_generator.output();
	
	std::cout << "\nPlease Note: The best strategy for winning the lottery is not to play.\n";
	return 0;
}

