/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   CA.cpp - source file for CA class
******************************************/

#include "CA.h"
#include "util.h"

#include <iostream>
#include <iterator>


// number of iterations of the CA to run for
#define NUM_ITERATIONS 75



CA::CA()
	: current_grid(& grids [0])
	, previous_grid(& grids [1])
{
	init_rules();
	init_grid();
	
#if defined(CA_HISTOGRAM)
	memset(ball_tally, 0, sizeof(ball_tally));
#endif
}

CA::~CA()
{
#if defined(CA_HISTOGRAM)
	dump_tally();
#endif
}

// iterate for the prescribed number of times to jumble up all those bits in the grid
void CA::run()
{
	std::cout << "\nRunning CA...\n";
	// progress output counter
	int last_progress_value = -1;

	for (int i = 0; i < NUM_ITERATIONS; ++ i)
	{
		if (verbose)
		{
			std::cout << "\niteration # " << i << '\n';
		}
		else
		{
			int progress_value = 100 * i / NUM_ITERATIONS;
			if (progress_value != last_progress_value)
			{
				last_progress_value = progress_value;
				std::cout << '\r' << last_progress_value << '%';
				std::cout.flush();
			}
		}

		iterate();
	}

	std::cout << "\r     \r";
}

// print out results
void CA::output() const
{
	BallSequence sequence;

	// get and print the five main numbers
	pick_sequence(5, 55, sequence);
	std::copy(sequence.begin(), sequence.end(), std::ostream_iterator<int>(std::cout, " "));

	// get and print the extra number
	pick_sequence(1, 42, sequence);
	std::cout << '(' << sequence.front() << ")\n";
}

// allocate rule table and fill with random rules
void CA::init_rules()
{
	// number of cells in a cell's neighbourhood
	int const num_neighbourhood_cells = 3 * 3 * 3;	// 27

	// number of states a cell and its neighbours can be in
	int const num_neighbourhood_states = 1 << num_neighbourhood_cells;	// 134217728 or 0x8000000, apparently

	std::cout << "\ninitialising rules...\n" << std::flush;
	rules.resize(num_neighbourhood_states);
	rules.randomise();
	std::cout << "\tdone\n";
}

// write random values to the cells in current_grid
void CA::init_grid()
{
	std::cout << "\ninitialising grid...\n" << std::flush;
	current_grid->randomise();
	std::cout << "\tdone\n";
}

// progress to the next time step
void CA::iterate()
{
	flip_grids();

	int ratio[2] = { 0, 0 };
	
	// for every cell in the previous_grid,
	Xyz grid_coords;
	for (grid_coords.z = 0; grid_coords.z < GRID_SIDE; ++ grid_coords.z) 
	{
		for (grid_coords.y = 0; grid_coords.y < GRID_SIDE; ++ grid_coords.y) 
		{
			for (grid_coords.x = 0; grid_coords.x < GRID_SIDE; ++ grid_coords.x) 
			{
				// get the next state for that cell given neighbourhood cells in previous_grid
				bool next_state = calculate_next_state(grid_coords);

				// and write that to the new current_grid
				(* current_grid)[grid_coords] = next_state;

				++ ratio[next_state];
			}
		}
	}

	if (verbose)
	{
		std::cout << '\t';
		output();
	}

	print_ratio("\tgrid cells: ", ratio);

	dump_tally();
}

// calculate value that should be in given cell in current_grid from cells in previous_grid
bool CA::calculate_next_state(Xyz const & grid_coords) const
{
	int rule_index = 0;
	
	Xyz relative_neighbour_coords;	// sweeps from {-1,-1,-1} to {1,1,1}
	Xyz global_neighbour_coords;	// relative_neighbour_coords + grid_coords wrapped around
	
	for (relative_neighbour_coords.z = -1; relative_neighbour_coords.z <= 1; ++ relative_neighbour_coords.z) 
	{
		global_neighbour_coords.z = wrap_grid_coord(grid_coords.z + relative_neighbour_coords.z);
		
		for (relative_neighbour_coords.y = -1; relative_neighbour_coords.y <= 1; ++ relative_neighbour_coords.y) 
		{
			global_neighbour_coords.y = wrap_grid_coord(grid_coords.y + relative_neighbour_coords.y);
			
			for (relative_neighbour_coords.x = -1; relative_neighbour_coords.x <= 1; ++ relative_neighbour_coords.x) 
			{
				global_neighbour_coords.x = wrap_grid_coord(grid_coords.x + relative_neighbour_coords.x);
				
				// line up the 3*3*3 bits into an index
				rule_index <<= 1;				
				if ((*previous_grid)[global_neighbour_coords]) 
				{
					rule_index |= 1;
				}
			}
		}
	}
	
	// that index is the rule
	return rules.get(rule_index);
}

void CA::flip_grids()
{
	// rather like the front/back buffer in graphics
	std::swap(current_grid, previous_grid);
}

// return the value of a randomly selected cell in the previous_grid
bool CA::get_random_cell() const
{
	Xyz grid_coord = { random_int(GRID_SIDE), random_int(GRID_SIDE),  random_int(GRID_SIDE) };
	
	return (* current_grid)[grid_coord];
}

// return a number made up of a given number of really-quite-random bits
int CA::get_random_bits(int num_bits) const
{
	int r = 0;
	while ((num_bits --) > 0) 
	{
		r <<= 1;
		if (get_random_cell()) 
		{
			r |= 1;
		}
	}
	
	return r;
}

// fill output with num_balls unique numbers in the range (0, range]
void CA::pick_sequence(int num_balls, int range, BallSequence & sequence) const
{
	sequence.clear();
	
	// figure out how many bits are needed to express the numbers in the range
	int num_bits = 0;
	for (int r = range; r; ++ num_bits, r >>= 1)
	{
	}
	
	// while there are less than num_balls entries in output (and there are any numbers left to pick)
	while (sequence.size() < num_balls && sequence.size() < range) 
	{
		// pick a number
		int r = get_random_bits(num_bits) + 1;
		
		// is it in the given range?
		if (r > range) 
		{
			continue;
		}
		
		// has it been picked already?
		if (std::find(sequence.begin(), sequence.end(), r) != sequence.end()) 
		{
			continue;
		}

		sequence.push_back(r);

#if defined(CA_HISTOGRAM)
		if (r < TALLY_MAX)
		{
			++ ball_tally[r];
		}
#endif
	}

	sequence.sort();
}

void CA::dump_tally()
{
#if defined(CA_HISTOGRAM)
	int maximum = 0;
	for (int i = 1; i < TALLY_MAX; ++ i)
	{
		int t = ball_tally[i];
		if (t > maximum)
		{
			maximum = t;
		}
	}

	if (maximum == 0)
	{
		return;
	}

	std::cout << "\nResult Histogram:\n";
	for (int i = 1; i < TALLY_MAX; ++ i)
	{
		int t = ball_tally[i];
		std::cout << i << '\t' << t << '\t';

		for (int c = t * 165 / maximum; c; -- c)
		{
			std::cout << '#';
		}
		std::cout << '\n';
	}
#endif
}

