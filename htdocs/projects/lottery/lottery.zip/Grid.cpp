/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   Grid.cpp - source file for Grid class
******************************************/

#include "Grid.h"
#include "util.h"


void Grid::randomise()
{
	int ratio[2] = { 0, 0 };
	
	Xyz coords;
	for (coords.z = 0; coords.z < GRID_SIDE; ++ coords.z) 
	{
		for (coords.y = 0; coords.y < GRID_SIDE; ++ coords.y) 
		{
			for (coords.x = 0; coords.x < GRID_SIDE; ++ coords.x) 
			{
				bool cell = random_bool();
				
				(*this)[coords] = cell;
				++ ratio[cell];
			}
		}
	}

	print_ratio("\trandomised grid cells: ", ratio);
}

