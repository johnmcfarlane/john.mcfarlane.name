/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   Grid.h - header file for Grid class
******************************************/

#include "Xyz.h"


// 3d grid array
class Grid
{
public:
	
	void randomise();

	inline bool & operator [] (Xyz const & coords) {
		return array [coords.z][coords.y][coords.x];
	}

	inline bool const & operator [] (Xyz const & coords) const {
		return array [coords.z][coords.y][coords.x];
	}

private:

	bool array [GRID_SIDE] [GRID_SIDE] [GRID_SIDE];
};


