/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   BitFields.cpp - source file for BitFields class
******************************************/

#include <cassert>
#include <cstdlib>

#include "BitField.h"


BitField::BitField() 
	: num_bits(0), array(0) 
{
}

BitField::BitField(unsigned int nb) 
{
	create(nb);
}

BitField::~BitField() 
{
	destroy();
}

void BitField::resize(unsigned int nb) 
{
	destroy();
	
	if (nb != 0) 
	{
		create(nb);
	}
}

void BitField::resize(unsigned int nb, bool value) 
{
	resize(nb);
	set_all(value);
}

void BitField::clear() 
{
	set_all(false);
}

void BitField::set_all(bool value) 
{
	if (is_empty()) 
	{
		return;
	}
	
	unsigned int t_value = value ? static_cast<unsigned int>(-1) : 0;
	unsigned int const * array_end = get_end();
	for (unsigned int * iterator = array; iterator != array_end; ++ iterator) 
	{
		* iterator = t_value;
	}
}

void BitField::randomise()
{
	unsigned char const * end = reinterpret_cast<unsigned char const *>(get_end());
	for (unsigned char * iterator = reinterpret_cast<unsigned char *>(array); iterator != end; ++ iterator)
	{
#if (RAND_MAX == 0x7fffffff)
		* iterator = rand() >> 23;
#elif (RAND_MAX == 0x7fff)
		* iterator = rand() >> 7;
#else
#warning "RAND_MAX not defined or unrecognised value"
		* iterator = rand();
#endif
	}
}

void BitField::set(unsigned int index, bool value) 
{
	assert(index < num_bits);
	
	unsigned int & element = get_element(index);
	unsigned int bit = 1 << (index & (INDEX_SHIFT - 1));
	
	if (value) 
	{
		element |= bit;
	}
	else 
	{
		element &= ~ bit;
	}
}

bool BitField::get(unsigned int index) const
{
	assert(index < num_bits);
	
	unsigned int const & element = get_element(index);
	unsigned int bit = static_cast<unsigned int>(1) << (index & (INDEX_SHIFT - 1));
	
	return element & bit;
}

void BitField::create(unsigned int nb) 
{
	num_bits = nb;

	unsigned int num_elements = calc_num_elements(num_bits);
	array = new unsigned int [num_elements];
}

void BitField::destroy() 
{
	num_bits = 0;

	delete [] array;
	array = 0;
}

unsigned int const * const BitField::get_end() const 
{
	return array + get_num_elements();
}

int BitField::get_num_elements() const 
{
	return calc_num_elements(num_bits);
}

unsigned int BitField::calc_num_elements(int num_bits) 
{
	return (num_bits + BITS_PER_T - 1) >> INDEX_SHIFT;
}
