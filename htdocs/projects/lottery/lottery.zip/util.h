/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   util.h - useful global declarations etc.
******************************************/

#include <cstdlib>


extern bool verbose;


// returns random boolean value
inline bool random_bool()
{
	return static_cast<unsigned>(rand()) * 2 >= static_cast<unsigned>(RAND_MAX) + 1;
}

// returns random floating-point value in the range [0, 1)
inline float random_float()
{
	return static_cast<float>(rand()) / RAND_MAX;
}

// returns random integer value in the range [0, maximum)
inline int random_int(int maximum)
{
	return static_cast<int>(random_float() * maximum);
}

// seed random number generator
//void seed_rng();

// output stats on a pair of integers that are supposed to be roughly the same
void print_ratio(char const * title, int ratio [2]);


