/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   Xyz.h - header file for Xyz structure
******************************************/

#include <cassert>


// length of a side in the 3d grid of cells
#define GRID_SIDE 73


// grid coordinate
struct Xyz
{
	int x, y, z;
};


// quickly wrap a value to within [0, GRID_SIDE)
inline int wrap_grid_coord(int unwrapped)
{
	if (unwrapped < 0) {
		assert(unwrapped >= - GRID_SIDE);
		return unwrapped + GRID_SIDE;
	}
	else if (unwrapped >= GRID_SIDE) {
		assert(unwrapped < GRID_SIDE * 2);
		return unwrapped - GRID_SIDE;
	}
	else {
		return unwrapped;
	}
}


