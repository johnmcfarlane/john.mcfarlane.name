/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   BitFields.h - header file for BitFields class
******************************************/

#include <climits>


// simple, indexed BitField class
class BitField
{
public:

	BitField();
	BitField(unsigned int nb);
	~BitField();

	inline bool is_empty() const {
		return num_bits == 0;
	}
	
	void resize(unsigned int nb);	
	void resize(unsigned int nb, bool value);
	
	void clear();
	void set_all(bool value);
	void randomise();
	
	void set(unsigned int index, bool value);
	bool get(unsigned int index) const;

private:

	inline unsigned int & get_element(unsigned int bit) {
		return array[bit >> INDEX_SHIFT];
	}

	inline unsigned int const & get_element(unsigned int bit) const {
		return array[bit >> INDEX_SHIFT];
	}

	void create(unsigned int nb);
	void destroy();
	
	unsigned int const * const get_end() const;
	int get_num_elements() const;
	static unsigned int calc_num_elements(int num_bits);
	
	// types

	enum { 
		BITS_PER_T = sizeof(unsigned int) << 3,
#if (INT_MAX == 0x7FFFFFFF)
		INDEX_SHIFT = 5
#elif (INT_MAX == 0x7FFFFFFFFFFFFFFF)
		INDEX_SHIFT = 6
#endif
	};	
	
	// attributes

	unsigned int num_bits;
	unsigned int * array;
	
};	// class BitField

