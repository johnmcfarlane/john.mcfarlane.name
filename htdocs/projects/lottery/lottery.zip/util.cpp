/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   util.cpp - useful global definitions etc.
******************************************/

#include "util.h"

#include <iostream>


bool verbose = false;


// seed random number generator
/*void seed_rng()
{
	unsigned int seed = time(0);
	srand(seed);
	std::cout << "\nseed = " << seed << '\n';
}*/


// output stats on a pair of integers that are supposed to be roughly the same
void print_ratio(char const * title, int ratio [2])
{
	if (verbose)
	{
		int sum = ratio[0] + ratio[1];
		int lower = std::min(ratio[0], ratio[1]);
		double deviation = 1. - 2. * lower / sum;
		std::cout << title << ratio[0] << ':' << ratio[1] << " dev=" << deviation << '\n';
	}
}

