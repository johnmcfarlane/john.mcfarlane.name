/******************************************
   Lottery Number Generator
   (c)2007 John McFarlane
   http://john.mcfarlane.name/projects/lottery

   CA.h - header file for CA class
******************************************/

#include "BitField.h"
#include "Grid.h"

#include <list>


//#define CA_HISTOGRAM


// Cellular Automaton class
class CA
{
public:

	CA();
	~CA();

	void run();
	void output() const;

private:

	void init_rules();
	void init_grid();

	void iterate();
	bool calculate_next_state(Xyz const & grid_coords) const;
	void flip_grids();

	// The list of balls with numbers on that comes out of the tube.
	// They should be unique numbers within a range of values.
	typedef std::list<int> BallSequence;

	bool get_random_cell() const;
	int get_random_bits(int num_bits) const;
	void pick_sequence(int num_balls, int range, BallSequence & output) const;

	void dump_tally();

	// rule set
	BitField rules;

	// grid of cells
	Grid grids [2];

	Grid * current_grid;
	Grid * previous_grid;

#if defined(CA_HISTOGRAM)
	// count of different number that show up
	enum { TALLY_MAX = 55 };
	mutable int ball_tally[TALLY_MAX];
#endif
};

